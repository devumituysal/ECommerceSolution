﻿namespace App.Models.DTO.Product
{
    public class ProductCreateResponseDto
    {
        public int ProductId { get; set; }
    }
}
