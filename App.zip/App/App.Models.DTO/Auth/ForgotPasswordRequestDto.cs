﻿namespace App.Models.DTO.Auth
{
    public class ForgotPasswordRequestDto
    {
        public string Email { get; set; } = null!;
    }
}
