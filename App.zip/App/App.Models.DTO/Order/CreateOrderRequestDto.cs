﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.Models.DTO.Order
{
    public class CreateOrderRequestDto
    {
        public string Address { get; set; } = null!;
    }
}
