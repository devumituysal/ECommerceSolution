﻿namespace App.Models.DTO.Cart
{
    public class UpdateCartItemDto
    {
        public byte Quantity { get; set; }
    }
}
