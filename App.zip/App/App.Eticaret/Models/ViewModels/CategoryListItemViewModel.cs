﻿namespace App.Eticaret.Models.ViewModels
{
    public class CategoryListItemViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
