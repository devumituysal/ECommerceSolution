﻿namespace App.Eticaret.Models.ViewModels
{
    public class ProductCreateResponseViewModel
    {
        public int ProductId { get; set; }
    }
}
