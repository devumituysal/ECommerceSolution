﻿namespace App.Eticaret.Models.ViewModels
{
    public class OrderCreateResponseViewModel
    {
        public string OrderCode { get; set; } = null!;
    }
}
