﻿namespace App.Eticaret.Models.ViewModels
{
    public class RenewPasswordViewModel
    {
        public string Token { get; set; } = null!;
        public string NewPassword { get; set; } = null!;
    }
}
