﻿namespace App.Eticaret.Models.ApiResponses
{
    public class FileUploadResponse
    {
        public string FileName { get; set; } = null!;
    }
}
