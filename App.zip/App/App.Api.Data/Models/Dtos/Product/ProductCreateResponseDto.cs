﻿namespace App.Api.Data.Models.Dtos.Product
{
    public class ProductCreateResponseDto
    {
        public int ProductId { get; set; }
    }
}
