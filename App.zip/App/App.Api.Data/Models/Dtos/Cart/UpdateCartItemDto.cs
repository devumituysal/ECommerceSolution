﻿namespace App.Api.Data.Models.Dtos.Cart
{
    public class UpdateCartItemDto
    {
        public byte Quantity { get; set; }
    }
}
