﻿namespace App.Api.Data.Models.Dtos.Auth
{
    public class ForgotPasswordRequestDto
    {
        public string Email { get; set; } = null!;
    }
}
