﻿using System.ComponentModel.DataAnnotations;

namespace App.Api.Data.Models.Dtos.Contact
{
    public class CreateContactMessageDto
    {
        public string Name { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Message { get; set; } = null!;
    }
}
